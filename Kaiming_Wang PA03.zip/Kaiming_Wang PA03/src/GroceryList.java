//Kaiming Wang
//PA#03
//02/26/2020


public class GroceryList {
	GroceryItemOrder[] element;
	int length;
	
	public GroceryList() {
		this.element = new GroceryItemOrder[10];
		this.length = 0;
	}
	

	public void add (GroceryItemOrder item) {
		if (this.length>10) {
			System.out.println("This grocery list is full (reach 10 items).");
		} else {
			this.element[this.length] = item;
			length += 1;
		}
	}
	
	public int getTotalQuantity() {
		int result = 0;
		for (int i =0; i <this.length; i++) {
			result += this.element[i].getQuantity();
		}
		return result;
	}
	
	public double getTotalCost() {
		double cost = 0;
		for (int i =0; i <this.length; i++) {
			cost += this.element[i].getCost();
		}
		return cost;
	}
	
	public String toString() {
		String result = "";
		for (int i =0; i <this.length; i++) {
			result+=this.element[i];
			if (i<this.length-1) {
				result+=",";
			} else {
				result+=".";
			}
		}
		return result;
	}
}
