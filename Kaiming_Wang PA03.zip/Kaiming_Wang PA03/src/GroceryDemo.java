//Kaiming Wang
//PA#03
//02/26/2020

import java.util.Scanner;

public class GroceryDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GroceryList list = new GroceryList();
		
		Scanner sc =  new Scanner(System.in);
		System.out.println("My Grocery List (you can only have 10 items in the list)");
		System.out.println("Please enter an item to add to the list (item-name quantity price)");
		System.out.println("Enter \"quit\" to stop adding items to the list");
		
		while(sc.hasNextLine()) {
			String str = sc.nextLine();
			if (str.equals("quit")){
				break;
			} else {
				
				String[] arrayOfStr = new String[3];
				arrayOfStr = str.split(" ");
				String name = arrayOfStr[0];
				int quantity = Integer.parseInt(arrayOfStr[1]);
				double price = Double.parseDouble(arrayOfStr[2]);
				
				
				GroceryItemOrder item = new GroceryItemOrder(name, quantity, price);
				list.add(item);
			}
			
			
		}
		System.out.println("My list: [" + list +"]");
		System.out.println("Total grocery amount: $ "+ list.getTotalCost());
		System.out.println("Total number of items: " + list.getTotalQuantity());
	}
	
	

}
