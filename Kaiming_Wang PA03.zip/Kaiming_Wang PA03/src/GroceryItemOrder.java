//Kaiming Wang
//PA#03
//02/26/2020


public class GroceryItemOrder {
	
	String name;
	int quantity;
	double price;
	
	public GroceryItemOrder(String name, int quantity, double pricePerUnit) {
		this.name = name;
		this.quantity = quantity;
		this.price = pricePerUnit;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public double getCost() {
		return this.price*this.quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String toString(){
		return (quantity + " " + name +	" ");
	}
}
